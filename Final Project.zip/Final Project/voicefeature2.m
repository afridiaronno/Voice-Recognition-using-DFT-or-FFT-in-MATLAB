function [fPitch, u, f, F_out] = voicefeature2(b)

    % Normalize
    b = b / (max(abs(b)) + 1e-8);

    L = length(b);
    n = 1;
    % Downsampling: Original rate 48000 reduced to 4000 
    % for i = 1:12:L
    %    Fx(n) = b(i);
    %    n = n + 1;
    % end
    % n = n - 1;

    % Proper resample instead of manual decimation
    b_resampled = resample(b, 4000, 48000);
    n = length(b_resampled);
    Fx = b_resampled;  
    
    F_out = df_transform2(Fx); % Apply manual DFT 
    k = 0:n-1;
    f = (k/n) * 4000; % Frequency scaling for the 4000Hz range 
    
    % Locate 20 peaks in the 50Hz to 550Hz range 
    a = 101; 
    p = 150;
    for i = 1:20
        R = F_out(a:p); % Define the interval 
        m = max(abs(R)); % Find peak magnitude 
        Z(i) = find(abs(R) == m, 1);
        Z(i) = 100 + Z(i) + 50 * (i-1); % Shift index to correct frequency 
        a = a + 50;
        p = p + 50;
    end
    u = abs(F_out(Z)); % Magnitude of identified peaks 
    fPitch = (Z/n) * 4000; % Frequency values of those peaks 
end