function Xk = df_transform2(xn)
    N = length(xn); % Number of data points 
    Xk = zeros(1, N); % Initialize output 
    for k = 0:N-1
        for n = 0:N-1 % 1 to N written as such
            % Manual DFT calculation per the project formula 
            Xk(k+1) = Xk(k+1) + xn(n+1) * exp(-1j * 2 * pi * k * n / N);
        end
    end
end