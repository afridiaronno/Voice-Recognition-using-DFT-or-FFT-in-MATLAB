function [fPitch, u, f, F_out] = voicefeature_FFT(b)
    % voicefeature_FFT: Extracts voice features using built-in FFT
    % More Efficient Than DFT

    b = b / (max(abs(b)) + 1e-8); % +epsilon avoids divide-by-zero on silence
    
    L = length(b);
    n = 1;
    % Downsampling: Taking every 12th sample (48000Hz -> 4000Hz)
    %
    % for i = 1:12:L
    %     Fx(n) = b(i);
    %    n = n + 1;
    % end
    %  n = n - 1; 


    % --- STEP 2: Proper resampling with anti-aliasing (48000 → 4000 Hz) ---
    % resample() applies a low-pass filter before decimating — no aliasing

    targetFs = 4000;
    originalFs = 48000;
    b_resampled = resample(b, targetFs, originalFs);  % replaces the manual loop
    n = length(b_resampled);
    
    % --- THE SEAMLESS REPLACEMENT ---
    % We replace the slow manual df_transform2(Fx) with the built-in fft
    F_out = fft(b_resampled); 
    
    % Frequency axis scaling
    k = 0:n-1;
    f = (k/n) * 4000; 
    
    % Peak Detection Logic 
    a = 101; 
    p = 150;
    for i = 1:20
        R = F_out(a:p);
        m = max(abs(R));
        Z(i) = find(abs(R) == m, 1);
        Z(i) = 100 + Z(i) + 50 * (i-1);
        a = a + 50;
        p = p + 50;
    end
    u = abs(F_out(Z)); % Magnitude of the 20 peaks
    fPitch = (Z/n) * targetFs; % Frequencies of the 20 peaks
end