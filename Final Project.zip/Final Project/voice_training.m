clear all; close all; clc;

% =========================================================
%  VOICE TRAINING SCRIPT
%  - Files named: SpeakerName_Number.wav
%  - Multiple samples per speaker are averaged together
%  - Same Name_Number = overwrite prompt
%  - Different numbers = treated as separate training data
% =========================================================

% --- UPDATE THIS PATH TO TRAINING FOLDER ---
folderPath = 'D:\Final Project\VoiceTraining\';
% ------------------------------------------------

fileList = dir(fullfile(folderPath, '*.wav'));

if isempty(fileList)
    error('No .wav files found in: %s\nCheck the path is correct.', folderPath);
end

fprintf('Found %d .wav file(s) in folder.\n\n', length(fileList));

% =========================================================
%  STEP 1: Group files by speaker name
%  Shaha_1.wav, Shaha_2.wav  → all belong to speaker "Shaha"
%  Splits on underscore: everything before _ is speaker name
% =========================================================

speakerMap = containers.Map();

for i = 1:length(fileList)
    fileName = fileList(i).name;
    fullPath = fullfile(folderPath, fileName);
    rawName  = erase(fileName, '.wav');       % e.g. 'Shaha_1'

    % Split on underscore to get speaker name
    parts = strsplit(rawName, '_');

    if length(parts) >= 2
        % Has underscore: Mirza_1 → speakerName = 'Mirza'
        speakerName = parts{1};
    else
        % No underscore: treat whole filename as speaker name
        speakerName = rawName;
    end

    if isKey(speakerMap, speakerName)
        speakerMap(speakerName) = [speakerMap(speakerName), {fullPath}];
    else
        speakerMap(speakerName) = {fullPath};
    end
end

speakerNames = keys(speakerMap);
numSpeakers  = length(speakerNames);

fprintf('Unique speakers found: %d\n', numSpeakers);
for i = 1:numSpeakers
    files = speakerMap(speakerNames{i});
    fprintf('  %-15s — %d sample(s)\n', speakerNames{i}, length(files));
end
fprintf('\n');

% =========================================================
%  STEP 2: Extract features and average per speaker
% =========================================================

F  = zeros(numSpeakers, 20);
FS = strings(1, numSpeakers);

successCount = 0;

for i = 1:numSpeakers
    spkName   = speakerNames{i};
    fileGroup = speakerMap(spkName);
    numFiles  = length(fileGroup);

    tempF        = zeros(numFiles, 20);
    validSamples = 0;

    fprintf('Training: %s\n', spkName);

    for s = 1:numFiles
        fullPath = fileGroup{s};
        [~, thisFile, ~] = fileparts(fullPath); 
        % Keeping only the file name without extension or path%

        try
            % Check duration
            info = audioinfo(fullPath);
            if info.TotalSamples < 192000
                fprintf('  [%s] SKIPPED — too short (need at least 4s)\n', thisFile);
                continue;
            end

            % Read 2s to 4s segment
            [b1, ~] = audioread(fullPath, [96000, 192000]);

           
            

            b = b1(:,1);
            % Normalize before feature extraction

            b = b / (max(abs(b)) + 1e-8);

            % Extract 20 peak frequencies only
            % voicefeature2 returns [fPitch, u, f, F_out]

            %[fPitch, ~, ~, ~] = voicefeature2(b);
            
            [fPitch, ~, ~, ~] = voicefeature_FFT(b);

            tempF(s,:)   = fPitch;
            validSamples = validSamples + 1;

            fprintf('  [%s] OK\n', thisFile);

        catch ME
            fprintf('  [%s] ERROR — %s\n', thisFile, ME.message);
        end
    end

    if validSamples == 0
        fprintf('  No valid samples for %s — skipping speaker\n\n', spkName);
        continue;
    end

    % Average across all valid samples only
    validRows = any(tempF ~= 0, 2);
    F(i,:) = mean(tempF(validRows, :), 1);
    FS(i)  = spkName;

    successCount = successCount + 1;
    fprintf('  Averaged %d sample(s) → stored as [%s]\n\n', validSamples, spkName);
end

% =========================================================
%  STEP 3: Remove empty rows and save
% =========================================================

validIdx = FS ~= "";
F  = F(validIdx, :);
FS = FS(validIdx);

save database.mat F FS

% =========================================================
%  SUMMARY
% =========================================================

fprintf('=========================================\n');
fprintf('Training complete.\n');
fprintf('Speakers trained:  %d / %d\n', successCount, numSpeakers);
fprintf('\nDatabase contents:\n');
for i = 1:length(FS)
    fprintf('  [%d] %s\n', i, FS(i));
end
fprintf('\ndatabase.mat saved to current folder.\n');
fprintf('=========================================\n');
